// M169 Mini-Projekt – main.js

// Zeigt die aktuelle Zeit im Tab-Titel
function updateTitle() {
  const now = new Date().toLocaleTimeString('de-CH');
  document.title = `M169 Docker | ${now}`;
}
setInterval(updateTitle, 1000);

// Badge "Container läuft seit X Sekunden"
const startTime = Date.now();
const badge = document.querySelector('.badge.green');
if (badge) {
  setInterval(() => {
    const secs = Math.floor((Date.now() - startTime) / 1000);
    badge.textContent = `🟢 Läuft seit ${secs}s`;
  }, 1000);
}

// Smooth Scroll für Navigation
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const target = document.querySelector(link.getAttribute('href'));
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  });
});

console.log('%c🐳 M169 Docker Container läuft!', 'color: #2980b9; font-size: 16px; font-weight: bold;');
console.log('Luka Aurelius Sola | GBS St. Gallen | Varioprint AG');
