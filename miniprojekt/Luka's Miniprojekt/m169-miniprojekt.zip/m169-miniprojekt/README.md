# 🐳 M169 Mini-Projekt – Docker Webserver

**Modul:** M169 – Services mit Containern bereitstellen  
**Lernende/r:** Luka Aurelius Sola  
**Schule:** GBS St. Gallen  
**Betrieb:** Varioprint AG (via LIBS)

---

## 📁 Projektstruktur

```
m169-miniprojekt/
├── Dockerfile          # Eigenes NGINX-Image auf Alpine-Basis
├── docker-compose.yml  # Service-Definition mit Volumes & Healthcheck
├── nginx.conf          # NGINX-Konfiguration
├── website/            # Website-Dateien (via Volume gemountet)
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── logs/               # NGINX-Logs (automatisch befüllt)
│   ├── access.log
│   └── error.log
└── README.md
```

---

## 🚀 Starten

### Voraussetzungen
- Docker Desktop installiert
- Terminal / PowerShell im Projektordner

### 1. Container starten
```bash
docker compose up -d
```

### 2. Website aufrufen
```
http://localhost:8080
```

### 3. Container stoppen
```bash
docker compose down
```

---

## 🔧 Weitere nützliche Befehle

```bash
# Logs live anschauen
docker compose logs -f

# In den Container einsteigen
docker exec -it m169-webserver sh

# Container-Status prüfen
docker ps

# Alles neu bauen (nach Dockerfile-Änderung)
docker compose up -d --build

# Logs lokal lesen
cat logs/access.log
```

---

## 📝 Wie live Änderungen funktionieren

Die Website-Dateien (`website/`) sind als **Volume** in den Container gemountet.  
Das heisst: Änderungen an HTML/CSS/JS sind **sofort** im Browser sichtbar — ohne Neustart!

```bash
# Beispiel: index.html ändern → Seite neu laden → fertig ✅
```

---

## 📊 Technische Details

| Eigenschaft | Wert |
|---|---|
| Basis-Image | nginx:alpine |
| Container-Port | 80 |
| Host-Port | 8080 |
| Website-Ordner | `./website` → `/usr/share/nginx/html` |
| Logs | `./logs` → `/var/log/nginx` |
| Healthcheck | alle 30s via wget |
| Restart-Policy | unless-stopped |
