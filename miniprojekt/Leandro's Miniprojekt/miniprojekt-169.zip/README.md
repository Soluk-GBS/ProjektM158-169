# Mini-Projekt – Modul 293

Containerisierter NGINX-Webserver, erreichbar auf **Port 8080**.

## Projektstruktur

```
mini-projekt/
├── Dockerfile
├── docker-compose.yml
├── nginx.conf
├── index.html
├── style.css
├── logs/          ← wird automatisch erstellt (NGINX-Logs)
└── README.md
```

## Starten

```bash
# Image bauen & Container starten
docker-compose up -d

# Website aufrufen
open http://localhost:8080
```

## Stoppen

```bash
docker-compose down
```

## Logs anschauen

```bash
# Lokal im logs/-Verzeichnis:
cat logs/access.log
cat logs/error.log

# Oder direkt im Container:
docker logs mini-projekt-nginx
```

## Anforderungen (Aufgabe 2.3)

| Anforderung | Umsetzung |
|---|---|
| Eigenes Webserver-Image | `Dockerfile` mit `nginx:alpine` als Basis |
| Einfache Webseite | `index.html` + `style.css` |
| Port 8080 | `nginx.conf` → `listen 8080` + Compose-Port-Mapping |
| Website-Dateien lokal | Volume-Mount `./index.html`, `./style.css` |
| Logs lokal | Volume-Mount `./logs:/var/log/nginx` |

## Technologien

- **NGINX** (Alpine) als Webserver
- **Docker** / **docker-compose** für Containerisierung
- **HTML5 / CSS3** für die Website
